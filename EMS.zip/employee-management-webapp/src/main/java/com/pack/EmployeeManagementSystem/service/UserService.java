package com.pack.EmployeeManagementSystem.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.pack.EmployeeManagementSystem.dto.UserRegistrationDto;
import com.pack.EmployeeManagementSystem.model.User;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
